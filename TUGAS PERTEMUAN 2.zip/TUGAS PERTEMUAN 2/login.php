<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="potoaku.jpg">
    <title>Tugas Pertemuan 2</title>
</head>
<body style="background-image:url(unsri.png);display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0;">
    <div style="background-color: white; padding: 20px; border-radius: 10px;">
        <form action="biodata.php">
            Username: <input type="text" id="uname" name="uname" placeholder="Masukkan Username anda ..." required>
            <br><br>
            Password: <input type="password" id="pw" name="pw" placeholder="Masukkan Password anda ..." required>
            <br><br>
            <input type="submit">
        </form>
    </div>
</body>
</html>
